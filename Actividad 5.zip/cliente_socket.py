# cliente_socket.py
import socket

HOST = '127.0.0.1'
PORT = 65432

with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as cliente:
    cliente.connect((HOST, PORT))
    mensaje = "Hola desde el cliente"
    cliente.sendall(mensaje.encode())
    respuesta = cliente.recv(1024)
    print(f"Respuesta del servidor: {respuesta.decode()}")

# servidor_socket.py
import socket

HOST = '127.0.0.1'  # Dirección del servidor
PORT = 65432        # Puerto del servidor

with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as servidor:
    servidor.bind((HOST, PORT))
    servidor.listen()
    print(f"Servidor escuchando en {HOST}:{PORT}...")
    conn, addr = servidor.accept()
    with conn:
        print(f"Conexión desde {addr}")
        mensaje = conn.recv(1024)
        if mensaje:
            print(f"Mensaje del cliente: {mensaje.decode()}")
            respuesta = "Mensaje recibido correctamente"
            conn.sendall(respuesta.encode())

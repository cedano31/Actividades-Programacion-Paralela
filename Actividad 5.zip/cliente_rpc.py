# cliente_rpc.py
import xmlrpc.client

proxy = xmlrpc.client.ServerProxy("http://localhost:8000/")

try:
    numero = int(input("Introduce un número entero: "))
    resultado = proxy.cuadrado(numero)
    print(f"El cuadrado de {numero} es {resultado}")
except Exception as e:
    print(f"Error: {e}")

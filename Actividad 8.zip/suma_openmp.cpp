#include <iostream>      // Para impresión en consola
#include <vector>        // Para usar std::vector
#include <cstdlib>       // Para rand()
#include <omp.h>         // Librería de OpenMP

//Gabriel Cedano 24-1242

int main() {
    int N = 1048576; // 1 millón de elementos
    std::vector<float> A(N), B(N), C(N); // Declaración de vectores A, B, y C

    // Inicializamos los vectores A y B con valores aleatorios
    for (int i = 0; i < N; i++) {
        A[i] = static_cast<float>(rand()) / RAND_MAX; // Valor aleatorio entre 0 y 1
        B[i] = static_cast<float>(rand()) / RAND_MAX; // Valor aleatorio entre 0 y 1
    }

    double start = omp_get_wtime(); // Tiempo inicial antes del bucle paralelo

    // Bucle paralelo con OpenMP para realizar la suma
    #pragma omp parallel for
    for (int i = 0; i < N; i++) {
        C[i] = A[i] + B[i]; // Operación de suma paralela
    }

    double end = omp_get_wtime(); // Tiempo final después del bucle paralelo

    // Imprimimos el tiempo total de ejecución
    std::cout << "Tiempo CPU (OpenMP): " << (end - start) << " segundos" << std::endl;

    // Verificamos los primeros 5 resultados para comprobar que la suma es correcta
    for (int i = 0; i < 5; i++) {
        std::cout << "C[" << i << "] = " << C[i] << " (A + B = " << A[i] + B[i] << ")\n";
    }

    return 0; // Fin del programa
}
